# NHS_ANALYSIS
Analysis of National Health Service(NHS), London dataset on drug prescriptions by various General practice practitioners (GPs)
